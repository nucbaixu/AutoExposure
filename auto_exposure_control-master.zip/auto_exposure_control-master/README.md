# auto-exposure-control

Auto Exposure Control allows for software based exposure setting for ROS based cameras.
It is assumed that there is a dynamic reconfigure server with a parameter called 'exposure_value'.

The code is based on the paper
"Automatic Camera Exposure Control", N. Nourani-Vatani, J. Roberts

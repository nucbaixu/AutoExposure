# -*- coding: utf-8 -*-
"""
Created on Mon Jul 27 17:03:23 2020

@author: Wei Huajing
@company: KAMERAWERK
@e-mail: jerryweihuajing@126.com

@title: Module-Cofiguration of fonts
"""

#font of fonts of all kinds
legend_prop={'family':'Gill Sans MT',
             'weight':'normal',
             'style':'normal',
             'size':12}

sample_prop={'family':'Gill Sans MT',
             'weight':'normal',
             'style':'normal',
             'size':10}

text_prop={'family':'Gill Sans MT',
           'weight':'normal',
           'style':'italic',
           'size':12}

annotation_prop={'family':'Gill Sans MT',
                 'weight':'normal',
                 'style':'normal',
                 'size':14}

label_prop={'family':'Gill Sans MT',
            'weight':'normal',
            'style':'italic',
            'size':16}

title_prop={'family':'Gill Sans MT',
            'weight':'normal',
            'style':'normal',
            'size':18}

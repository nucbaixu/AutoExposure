// -*- coding: utf-8 -*-
/******************************************************************************
Created on Mon Oct 19 14:51:37 2020

@author: Wei Huajing
@company: KAMERAWERK
@e-mail: wei@kamerawerk.cn

@title: Source-frame object
******************************************************************************/

#include "..\Header\object_frame.h"

frame::frame() {
	
	cout << "-- Object Init: frame" << endl;
}